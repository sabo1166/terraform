import json
from datetime import datetime


def lambda_handler(event, context):
    current_time = datetime.utcnow().isoformat()

    response = {
        "message": "Hello from AWS Lambda!",
        "status": "success",
        "time": current_time,
        "event": event
    }

    print(json.dumps(response))

    return {
        "statusCode": 200,
        "body": json.dumps(response)
    }